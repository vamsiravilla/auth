from django.shortcuts import render,HttpResponseRedirect
from app1.forms import Signup
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate,login,logout

#-----------------------------------------------------------#

from app1.models import Crud_model
from app1.forms import Curd_form
from django.http import HttpResponseRedirect

# Create your views here.

def signup(request):
    if request.method=='POST':
        fm = Signup(request.POST)
        if fm.is_valid():
            messages.success(request,'account created sucssesfully')
            fm.save()
    else:
        fm = Signup()
    return render(request,'signup.html',{'form':fm})


def login_page(request):
    if not request.user.is_authenticated:
        if request.method == 'POST':
            fm = AuthenticationForm(request=request,data=request.POST)
            if fm.is_valid():
                username = fm.cleaned_data['username']
                password = fm.cleaned_data['password']
                db=authenticate(username=username,password=password)
                db.save()
                if db is not None:
                    login(request,db)
                    messages.success(request,'Updated Succssesfully')
                    return HttpResponseRedirect('/profile/')
        else:
            fm = AuthenticationForm()
            return render(request,'login.html',{'form':fm})
    else:
        return HttpResponseRedirect('/profile/')


def profile_page(request):
    if request.user.is_authenticated:
        return render(request, 'userprofile.html', {"name": request.user})
    else:
        return HttpResponseRedirect('/login/')

def logoutuser(request):
    logout(request)
    return HttpResponseRedirect('/login/')






# Create your views here.
def Crud(request):
    if request.method == 'POST':
        fm = Curd_form(request.POST)
        if fm.is_valid():
            RoomType = fm.cleaned_data['RoomType']
            num_of_guests = fm.cleaned_data['num_of_guests']
            Fullname = fm.cleaned_data['Fullname']
            start_date = fm.cleaned_data['start_date']
            end_date = fm.cleaned_data['end_date']
            mob = fm.cleaned_data['mob']
            email = fm.cleaned_data['email']
            message = fm.cleaned_data['message']

            db = Crud_model(RoomType=RoomType,num_of_guests=num_of_guests,Fullname=Fullname,start_date=start_date,end_date=end_date,mob=mob,email=email,message=message)
            db.save()
            fm = Curd_form()
    else:
        fm = Curd_form()
    data = Crud_model.objects.all()
    return render(request,'index.html',{'form':fm,'fetch': data})

def update(request,id):
    if request.method == 'POST':
        pi = Crud_model.objects.get(pk=id)
        fm = Curd_form(request.POST,instance=pi)
        if fm.is_valid():
            fm.save()
            messages.info(request,'Data Updated Successfully')

    else:
        pi = Crud_model.objects.get(pk=id)
        fm = Curd_form(instance=pi)

    return render(request,'update.html',{'form':fm})

def delete(request,id):
    if request.method == 'POST':
        fm = Crud_model.objects.get(pk=id)
        fm.delete()
        return HttpResponseRedirect('/')

